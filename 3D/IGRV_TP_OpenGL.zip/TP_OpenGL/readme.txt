Informatique Graphique 3D et R�alit� Virtuelle 

Travaux Pratique

OpenGL Classique : cd src; make -f Makefile.linux

Remplacer linux par cygwin pour une installation sous Linux/Cygwin

Contact: Tamy Boubekeur (tamy.boubekeur@telecom-paristech.fr)